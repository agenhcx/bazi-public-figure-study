#!/usr/bin/env python3
"""Render all five main figures and supplementary Figure S1, offline."""
from pathlib import Path
import sys, subprocess, json, hashlib
ROOT=Path(__file__).resolve().parent
for name in ('figure1','figure2','figure3','figure4','figure5','figureS1'):
    subprocess.run([sys.executable,str(ROOT/'scripts'/f'render_{name}.py')],check=True,cwd=ROOT)
for name in ('Fig1','Fig2','Fig3','Fig4','Fig5','S1_fig'):
    for ext in ('png','pdf','svg'):
        p=ROOT/'figures'/f'{name}.{ext}'
        assert p.is_file() and p.stat().st_size>1000,p
report={'status':'PASS','figures':['Fig1','Fig2','Fig3','Fig4','Fig5','S1_fig'],'outputs':18,'scope':'Frozen plotting inputs rendered offline; statistical analyses are not rerun.','input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((ROOT/'inputs').glob('*.csv'))},'checks':{p.stem:json.loads(p.read_text()) for p in sorted((ROOT/'verification').glob('*.json')) if p.name!='render_all.json'}}
(ROOT/'verification/render_all.json').write_text(json.dumps(report,indent=2))
print('PASS: all six figures rendered in figures/; verification/render_all.json records checks.')
