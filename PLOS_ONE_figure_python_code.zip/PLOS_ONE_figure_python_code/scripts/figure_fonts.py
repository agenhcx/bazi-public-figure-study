"""Require the publication font; never silently substitute a different family."""
from pathlib import Path
from matplotlib import font_manager


def use_arial():
    # Refresh newly installed Arial faces without relying on a stale cache.
    for candidate in font_manager.findSystemFonts(fontext='ttf'):
        if 'arial' in Path(candidate).name.lower():
            font_manager.fontManager.addfont(candidate)
    try:
        regular = font_manager.findfont(
            font_manager.FontProperties(family='Arial', weight='normal'),
            fallback_to_default=False,
        )
        bold = font_manager.findfont(
            font_manager.FontProperties(family='Arial', weight='bold'),
            fallback_to_default=False,
        )
    except ValueError as exc:
        raise RuntimeError(
            'Arial is required for these publication figures. Install a licensed '
            'Arial font (normally available on Windows), then rerun the renderer.'
        ) from exc
    for path in (regular, bold):
        if font_manager.FontProperties(fname=path).get_name() != 'Arial':
            raise RuntimeError('Arial was not resolved correctly: ' + path)
    return regular, bold
