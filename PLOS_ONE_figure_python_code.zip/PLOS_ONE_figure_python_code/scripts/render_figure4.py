"""Render archived Figure 4 plotted values; no new analysis."""
from common import *
import pandas as pd
from matplotlib.lines import Line2D
labels=LABELS
GRAY="#7A7F87"
BLUE=COLORS[0]
# Figure 4: historical versus modern table tennis
profile=pd.read_csv(INPUTS/'figure4_plotted_values.csv')
hist=profile['Historical 1950–1984 ratio'].to_numpy()
modern=profile['Modern 1985–2008 ratio'].to_numpy()
x = np.arange(len(labels))
w4 = 0.36
fig, ax = plt.subplots(figsize=(7.5, 4.65))
fig.subplots_adjust(top=0.90, bottom=0.22, left=0.09, right=0.985)
ax.axvspan(0.5, 1.5, color="#F5F1E9", zorder=0)
ax.bar(x - w4 / 2, hist - 1, bottom=1, width=w4, color=GRAY, edgecolor="white", linewidth=0.5,
       label="Historical 1950–1984 (N=335)", zorder=3)
ax.bar(x + w4 / 2, modern - 1, bottom=1, width=w4, color=BLUE, edgecolor="white", linewidth=0.5,
       label="Modern 1985–2008 (N=384)", zorder=3)
ax.axhline(1, color="#222222", lw=1.15, zorder=4)
sig_hist, sig_mod = 0.0775, 0.0689
for n in (1, 2, 3):
    for sign in (-1, 1):
        ax.axhline(1 + sign * n * sig_hist, color=GRAY, lw=0.6, ls=(0, (5, 3)), alpha=0.30, zorder=1)
        ax.axhline(1 + sign * n * sig_mod, color=BLUE, lw=0.6, ls=(0, (1.5, 2.2)), alpha=0.28, zorder=1)
guide_handles = [
    Line2D([0], [0], color=GRAY, lw=1.0, ls=(0, (5, 3)), label="Historical σR≈0.0775"),
    Line2D([0], [0], color=BLUE, lw=1.0, ls=(0, (1.5, 2.2)), label="Modern σR≈0.0689"),
]
ax.set_ylabel("Observed / calendar-null ratio (R)")
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_ylim(0.75, 1.25)
ax.set_yticks(np.arange(0.75, 1.251, 0.05))
fig.legend(*ax.get_legend_handles_labels(), ncol=2, frameon=False, loc="lower center",
           bbox_to_anchor=(0.5375, 0.917), borderaxespad=0)
ax.legend(handles=guide_handles, ncol=1, frameon=False, loc="lower right", bbox_to_anchor=(0.998, 0.012), fontsize=8.3,
          handlelength=2.3, borderaxespad=0.2)
ax.text(1, 0.755, "Largest cohort contrast", ha="center", va="bottom", fontsize=8.3, color="#8A5E24", fontweight="bold")
clean_axes(ax, ygrid=False)
verify_bars(ax,[hist,modern],"Fig4",1,["Historical 1950–1984 (N=335)","Modern 1985–2008 (N=384)"])
finish(fig, "Fig4")


