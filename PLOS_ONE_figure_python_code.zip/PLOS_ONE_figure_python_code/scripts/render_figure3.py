"""Render verified frozen Figure 3 values; no new analysis."""
from common import *
import pandas as pd
data=pd.read_csv(INPUTS/"figure3_verified_source.csv")
features=["Direct Resource","Indirect Resource","Any Resource","Seven Killings","Any Wealth","Direct Officer"]
cohorts=["2013_M_DISCOVERY","2023_M_FULL","2023_M_NEW_TARGET"]
data=pd.concat([data[data.cohort.eq(k)].set_index("feature").loc[features].reset_index() for k in cohorts],ignore_index=True)
plt.rcParams.update({"font.family":"Arial", "font.size":9.2, "axes.titlesize":12, "axes.labelsize":10,
    "axes.edgecolor":"#444444", "axes.linewidth":.8, "xtick.labelsize":8.2, "ytick.labelsize":8.5,
    "legend.fontsize":8.3, "figure.facecolor":"white", "axes.facecolor":"white", "savefig.facecolor":"white"})
fig, ax = plt.subplots(figsize=(7.35,4.35))
fig.subplots_adjust(top=.90,bottom=.22,left=.10,right=.985)
colors=["#3B6FB6","#E07A28","#4B9A67"]
labels=["2013 consistency", "2023 full", "2023 new target"]
x=np.arange(len(features)); w=.245
for i, cohort in enumerate(cohorts):
    z=data.loc[data.cohort.eq(cohort),"z"].to_numpy()
    ax.bar(x+(i-1)*w,z,width=w,color=colors[i],edgecolor="white",linewidth=.5,label=labels[i],zorder=3)
ax.axhline(0,color="#222222",lw=1.15,zorder=4)
for val in (-2,-1,1,2):
    ax.axhline(val,color="#A8ADB4",lw=.65,ls=(0,(3,3)),alpha=.75,zorder=1)
ax.set_ylabel("Conditional-null deviation (Z)")
ax.set_xticks(x); ax.set_xticklabels([f.replace(" ","\n",1) for f in features])
ax.set_ylim(-2.55,2.75); ax.set_yticks(np.arange(-2,3,1))
ax.legend(ncol=3,frameon=False,loc="lower center",bbox_to_anchor=(.50,1.025),borderaxespad=0)
ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
for ext in ("png","svg","pdf"):
    fig.savefig(OUT / ("Fig3."+ext),dpi=300,bbox_inches="tight",pad_inches=.12)
verify_bars(ax,[data.loc[data.cohort.eq(k),"z"].to_numpy() for k in cohorts],"Fig3",0,labels)
plt.close(fig)
