from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from figure_fonts import use_arial
use_arial()
ROOT=Path(__file__).resolve().parent.parent
INPUTS=ROOT/"inputs"
OUT=ROOT/"figures"
VERIFY=ROOT/"verification"
for d in (OUT,VERIFY):d.mkdir(exist_ok=True)
LABELS=["Friend","Rob\nWealth","Eating\nGod","Hurting\nOfficer","Indirect\nWealth","Direct\nWealth","Seven\nKillings","Direct\nOfficer","Indirect\nResource","Direct\nResource"]
COLORS=["#3B6FB6","#E07A28","#4B9A67"]
plt.rcParams.update({"font.family":"Arial","font.size":9.2,"axes.titlesize":12,"axes.labelsize":10,"axes.edgecolor":"#444444","axes.linewidth":.8,"xtick.labelsize":8.2,"ytick.labelsize":8.5,"legend.fontsize":8.3,"figure.facecolor":"white","axes.facecolor":"white","savefig.facecolor":"white","pdf.fonttype":42,"ps.fonttype":42,"svg.fonttype":"none"})
def finish(fig,name):
    for ext in ("png","pdf","svg"):fig.savefig(OUT/f"{name}.{ext}",dpi=300,bbox_inches="tight",pad_inches=.08)
    plt.close(fig)
def clean_axes(ax,ygrid=False):
    ax.spines["top"].set_visible(False);ax.spines["right"].set_visible(False)
    if ygrid:ax.grid(axis="y",color="#D9DDE3",linewidth=.65,alpha=.8);ax.set_axisbelow(True)
def verify_bars(ax,expected,name,baseline,labels):
    actual=np.array([[p.get_y()+p.get_height() for p in c] for c in ax.containers])
    expected=np.array(expected)
    np.testing.assert_array_equal(actual,expected)
    bottoms=np.array([[p.get_y() for p in c] for c in ax.containers])
    np.testing.assert_array_equal(bottoms,np.full_like(bottoms,baseline))
    (VERIFY/f"{name}.json").write_text(json.dumps({"status":"PASS","numeric_values_preserved":int(actual.size),"bar_origin":baseline,"plotted_values":actual.tolist(),"series_order":labels,"no_statistical_recalculation":True},indent=2))
