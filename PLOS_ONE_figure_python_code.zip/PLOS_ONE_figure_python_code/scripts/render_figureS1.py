"""Render female M0 profiles and approximate mean-sigma guides; no new tests."""
from common import *
import pandas as pd
TGS=['比肩','劫财','食神','伤官','偏财','正财','七杀','正官','偏印','正印']
d=pd.read_csv(INPUTS/'Table_S1_female_M0_distributions.csv')
plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(13.6,5.25),layout='constrained')
x=np.arange(10);w=.24;expected=[];names=[]
for j,(cohort,label,color) in enumerate([('2013_F','2013 female (n = 200)','#4477AA'),('2023_F_FULL','2023 full female (n = 202)','#EE9944'),('2023_F_NEW_TARGET','2023 new-target female (n = 200)','#228877')]):
    q=d[d.cohort.eq(cohort)].set_index('ten_god').loc[TGS]
    values=q.enrichment_ratio.to_numpy();expected.append(values);names.append(label)
    ax.bar(x+(j-1)*w,values-1,bottom=1,width=w,label=label,color=color,edgecolor='white',linewidth=.6,zorder=3)
ax.axhline(1,color='#202020',lw=1.2,zorder=4)
# Match Fig2's visual reference convention. Each cohort-category cell has its
# own exact sigma_R = null SD / expected count; only the mean is used for the
# approximate horizontal guides. These are not common exact test thresholds.
sigma_values=(d.analytic_null_sd/d.null_total_exact).to_numpy()
sigma=float(sigma_values.mean())
for n in (1,2,3):
    for sign in (-1,1):
        ax.axhline(1+sign*n*sigma,color='#777777',lw=.65 if n<3 else .8,
                   ls=(0,(2,2)) if n<3 else (0,(5,3)),alpha=.55,zorder=1)
        ax.text(9.62,1+sign*n*sigma+sign*.003,
                ('+' if sign>0 else '−')+f'{n}σ',ha='right',
                va='bottom' if sign>0 else 'top',fontsize=8,color='#666666')
ax.set_ylim(.65,1.35);ax.set_yticks(np.arange(.7,1.31,.1));ax.set_xlim(-.6,9.75)
ax.set_ylabel('Observed count / calendar-null expected count (R)')
ax.set_xticks(x,LABELS);ax.tick_params(axis='x',length=0)
ax.set_title('Female chess cohorts: M0 Ten-God distributions',loc='left',fontsize=14,fontweight='bold',pad=12)
ax.legend(loc='upper left',ncol=3,frameon=False,fontsize=9)
fig.supxlabel('Solid line: calendar expectation (R = 1). Dashed guides: approximate ±1, ±2, ±3 mean σR across the 30 cells.\nExact cell-specific σR = null SD / expected count; see S1 Table. Post-reveal descriptive audit; full and new-target cohorts overlap.',fontsize=9)
verify_bars(ax,expected,'S1_fig',1,names)
verification_path=VERIFY/'S1_fig.json'
verification=json.loads(verification_path.read_text())
verification.update({'sigma_guide_convention':'Approximate mean of exact cell-specific sigma_R, matching Fig2',
                     'mean_sigma_R':sigma,
                     'cell_sigma_R_range':[float(sigma_values.min()),float(sigma_values.max())],
                     'sigma_guide_positions':{str(n):[1-n*sigma,1+n*sigma] for n in (1,2,3)},
                     'ordinary_y_grid_disabled':True})
verification_path.write_text(json.dumps(verification,indent=2))
for suffix in ('png','svg','pdf'):fig.savefig(OUT/f'S1_fig.{suffix}',dpi=300)
plt.close(fig)
