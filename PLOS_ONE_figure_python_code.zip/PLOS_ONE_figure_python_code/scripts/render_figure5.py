"""Render archived Figure 5 values and annotations; no new analysis."""
from common import *
import pandas as pd
BLUE=COLORS[0]
RED="#C75252"
# Figure 5: fixed-window temporal comparison
windows = ["1955–1964", "1965–1974", "1975–1984", "1985–1994", "1995–2004"]
source=pd.read_csv(INPUTS/'figure5_plotted_values.csv')
tt=source[source.domain.eq('TT')]['ratio'].to_numpy()
ch=source[source.domain.eq('Chess')]['ratio'].to_numpy()
x = np.arange(len(windows))
fig, ax = plt.subplots(figsize=(7.35, 4.25))
fig.subplots_adjust(top=0.90, bottom=0.20, left=0.10, right=0.985)
ax.axhline(1, color="#222222", lw=1.15, zorder=1)
ax.plot(x, tt, color=BLUE, marker="o", ms=6.2, lw=1.9, label="Table tennis", zorder=3)
ax.plot(x, ch, color=RED, marker="s", ms=5.7, lw=1.9, label="Chess", zorder=3)
ax.axvline(2.5, color="#888888", lw=0.8, ls=(0, (4, 3)), zorder=1)
ax.text(2.53, 0.73, "1985 cohort boundary", rotation=90, va="bottom", ha="left", fontsize=8.3, color="#666666")
ax.set_ylabel("Observed / calendar-null ratio (R)")
ax.set_xticks(x)
ax.set_xticklabels(windows)
ax.set_ylim(0.64, 1.27)
ax.set_yticks(np.arange(0.7, 1.251, 0.1))
ax.legend(frameon=False, loc="upper left")
ax.text(0.985, 0.06, "Table tennis: ρ=0.11368, directional p=.011\nChess: ρ=0.02198, directional p=.428",
        transform=ax.transAxes, ha="right", va="bottom", fontsize=8.1,
        bbox=dict(boxstyle="round,pad=0.28", facecolor="white", edgecolor="#C9CDD2", linewidth=0.7, alpha=0.92))
clean_axes(ax, ygrid=True)
np.testing.assert_array_equal(ax.lines[1].get_ydata(),tt)
np.testing.assert_array_equal(ax.lines[2].get_ydata(),ch)
(VERIFY/'Fig5.json').write_text(json.dumps({'status':'PASS','numeric_values_preserved':10,'series_order':['Table tennis','Chess'],'plotted_values':[tt.tolist(),ch.tolist()],'annotation':'Table tennis: ρ=0.11368, directional p=.011; Chess: ρ=0.02198, directional p=.428','no_statistical_recalculation':True},indent=2))
finish(fig, "Fig5")

