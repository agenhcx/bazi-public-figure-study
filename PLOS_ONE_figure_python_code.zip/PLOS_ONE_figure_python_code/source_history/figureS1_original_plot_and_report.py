#!/usr/bin/env python3
import json,hashlib,shutil
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
OUT=Path(__file__).resolve().parent
TGS=['比肩','劫财','食神','伤官','偏财','正财','七杀','正官','偏印','正印']
EN=['Friend','Rob Wealth','Eating God','Hurting Officer','Indirect Wealth','Direct Wealth','Seven Killings','Direct Officer','Indirect Resource','Direct Resource']
d=pd.read_csv(OUT/'female_m0_distribution_exact.csv')
f1=OUT/'inputs/first_reveal_results.json'
f2=OUT/'inputs/chess_2023_validation_results.json'
r1=json.loads(f1.read_text())['confirmatory']['C3_calendar_null']['2013_F']
r2=json.loads(f2.read_text())['selection']
rows=[]
for cohort,r in [('2013_F',r1),('2023_F_FULL',r2['F_FULL']),('2023_F_NEW_TARGET',r2['F_NEW_TARGET'])]:
    for tg,key in [('伤官','shangguan_count_6pos' if cohort=='2013_F' else 'H2_shangguan'),('偏印','pianyin_count_6pos' if cohort=='2013_F' else 'pianyin_descriptive_null')]:
        a=r[key];q=d[d.cohort.eq(cohort)&d.ten_god.eq(tg)].iloc[0]
        rows.append(dict(cohort=cohort,ten_god=tg,frozen_observed=a['observed_sum'],audit_observed=q.observed_total,observed_count_matches=a['observed_sum']==q.observed_total,frozen_MC_expected=a['null_mean_sum'],exact_expected=q.null_total_exact,frozen_MC_sd=a['null_sd_sum'],analytic_sd=q.analytic_null_sd,frozen_MC_Z=a['z'],exact_Z=q.z_exact,frozen_MC_p_high=a['empirical_p_high'],exact_p_high=q.p_high_exact,frozen_MC_p_low=a['empirical_p_low'],exact_p_low=q.p_low_exact,MC_replicates=a['n_sims'],MC_expected_minus_exact_in_MCSE=(a['null_mean_sum']-q.null_total_exact)/(a['null_sd_sum']/np.sqrt(a['n_sims']))))
c=pd.DataFrame(rows);c.to_csv(OUT/'female_original_HO_IR_comparison.csv',index=False)
d['model']='M0_5pos_mainqi';d['analysis_role']='post-reveal descriptive female audit';d['p_method']='exact finite convolution; inclusive tails; p_two_sided=min(1,2*min(p_high,p_low))';d['null_calendar']='uniform Gregorian date in each player birth year; sxtwl2.0.7; fixed cohort sizes and year counts';d['exact_Z_definition']='(observed_total-null_total_exact)/analytic_null_sd';d['Holm_family']='holm10: ten categories within cohort; holm30: all thirty cohort-category rows; post-reveal descriptive'
vals=d.p_two_sided_exact.values;adj=np.empty(len(vals));run=0
for rank,i in enumerate(np.argsort(vals)):
    run=max(run,min(1,(len(vals)-rank)*vals[i]));adj[i]=run
d['holm30_two_sided_exact']=adj
for col in ['frozen_MC_expected','frozen_MC_sd','frozen_MC_Z','frozen_MC_p_high','frozen_MC_p_low','MC_replicates']:
    lookup=c.set_index(['cohort','ten_god'])[col]; d[col]=[lookup.get((r.cohort,r.ten_god),np.nan) for r in d.itertuples()]
d.to_csv(OUT/'female_m0_distribution_exact.csv',index=False)
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.spines.top':False,'axes.spines.right':False})
fig,ax=plt.subplots(figsize=(13.6,5.25),layout='constrained')
x=np.arange(10);w=.24
for j,(cohort,label,color) in enumerate([('2013_F','2013 female (n = 200)','#4477AA'),('2023_F_FULL','2023 full female (n = 202)','#EE9944'),('2023_F_NEW_TARGET','2023 new-target female (n = 200)','#228877')]):
    q=d[d.cohort.eq(cohort)].set_index('ten_god').loc[TGS]
    ax.bar(x+(j-1)*w,q.enrichment_ratio,w,label=label,color=color,edgecolor='white',linewidth=.6,zorder=3)
ax.axhline(1,color='#202020',lw=1.2,linestyle='--',zorder=4)
ax.set_ylim(0,1.43);ax.set_yticks(np.arange(0,1.41,.2));ax.grid(axis='y',color='#D8D8D8',lw=.6,zorder=0)
ax.set_ylabel('Observed count / calendar-null expected count (R)')
ax.set_xticks(x,[s.replace(' ','\n') for s in EN]);ax.tick_params(axis='x',length=0)
ax.set_title('Female chess cohorts: M0 Ten-God distributions',loc='left',fontsize=14,fontweight='bold',pad=12)
ax.legend(loc='upper left',ncol=3,frameon=False,fontsize=9)
fig.supxlabel('Five informative date-known positions; Day Stem serves as reference. Dashed line: calendar expectation (R = 1).\nPost-reveal descriptive audit; full and new-target cohorts overlap.',fontsize=9)
for suffix in ('png','svg','pdf'):fig.savefig(OUT/f'female_m0_distribution.{suffix}',dpi=220)
male=pd.read_csv(OUT/'inputs/male_frozen_distribution_long.csv');male=male[male.model.eq('M0_5pos_mainqi')]
summ=[]
for sex,z in [('F',d),('M',male)]:
    for cohort,q in z.groupby('cohort'):
        summ.append(dict(sex=sex,cohort=cohort,n=int(q.n.iloc[0]),mean_absolute_R_minus_1=np.mean(np.abs(q.enrichment_ratio-1)),max_absolute_R_minus_1=np.max(np.abs(q.enrichment_ratio-1))))
pd.DataFrame(summ).to_csv(OUT/'sex_descriptive_deviation_summary.csv',index=False)
prov={'repository':'agenhcx/bazi-public-figure-study','retrieved_commit':'a3a99464ac92de3b122cd45a377d56e8335d6e91','source_paths_and_Git_blob_SHA':{'chess_first_reveal_v1/bazi_2013_F.csv':'81d398c2b487aed749029d110dec528b79944469','chess_2023_reveal_v1/bazi_2023_F_FULL.csv':'199c6b3faa73d133428777f4121885784a3301c9','chess_2023_reveal_v1/bazi_2023_F_NEW_TARGET.csv':'9d9304bf92d5d528c745cdc69ce7268bb8983c2b','chess_tengod_distribution_v1/chess_tengod_distribution_long.csv':'ea08fc95f1acc8c5d64943ae3b1336b4862f7664'},'input_sha256':{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted((OUT/'inputs').glob('*')) if p.is_file()}}
(OUT/'provenance.json').write_text(json.dumps(prov,indent=2))
print(c.to_string(index=False));print(pd.DataFrame(summ).to_string(index=False))
