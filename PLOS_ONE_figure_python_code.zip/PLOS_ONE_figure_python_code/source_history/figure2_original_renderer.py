#!/usr/bin/env python3
"""Layout-only update of Figure 2. Run: python render_figure2.py.
The adjacent CSV is copied byte-for-byte from the verified 501-person source.
Dependencies: numpy, pandas, matplotlib.
"""
from pathlib import Path
import json, hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
HERE=Path(__file__).resolve().parent
KEYS=['2013_M_DISCOVERY','2023_M_FULL','2023_M_NEW_TARGET']
plot=pd.read_csv(HERE/'figure2_n501_source.csv')
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':9.2,'axes.titlesize':12,'axes.labelsize':10,'axes.edgecolor':'#444444','axes.linewidth':.8,'xtick.labelsize':8.2,'ytick.labelsize':8.5,'legend.fontsize':8.3,'figure.facecolor':'white','axes.facecolor':'white','savefig.facecolor':'white'})
colors=['#3B6FB6','#E07A28','#4B9A67'];labels=['Friend','Rob\nWealth','Eating\nGod','Hurting\nOfficer','Indirect\nWealth','Direct\nWealth','Seven\nKillings','Direct\nOfficer','Indirect\nResource','Direct\nResource']
fig,ax=plt.subplots(figsize=(7.5,4.65));fig.subplots_adjust(top=.80,bottom=.23,left=.09,right=.985)
x=np.arange(10);w=.245;ax.axvspan(2.5,3.5,color='#EDF3FA',zorder=0)
for i,(k,label) in enumerate(zip(KEYS,['2013 (501)','2023 full (501)','2023 new (501)'])):
    ax.bar(x+(i-1)*w,plot[k+'_ratio']-1,bottom=1,width=w,color=colors[i],edgecolor='white',linewidth=.5,label=label,zorder=3)
ax.axhline(1,color='#222222',lw=1.15,zorder=4)
sigma=float(plot[[k+'_sigma_r' for k in KEYS]].to_numpy().mean())
for n in (1,2,3):
    for sign in (-1,1):ax.axhline(1+sign*n*sigma,color='#777777',lw=.65 if n<3 else .8,ls=(0,(2,2)) if n<3 else (0,(5,3)),alpha=.55,zorder=1)
    ax.text(9.58,1+n*sigma+.004,f'+{n}σ',ha='right',va='bottom',fontsize=7.2,color='#666666')
    ax.text(9.58,1-n*sigma-.004,f'−{n}σ',ha='right',va='top',fontsize=7.2,color='#666666')
fig.suptitle('Ten-God profiles across male elite-chess cohorts',x=.09,y=.975,ha='left',fontweight='bold',fontsize=12)
fig.text(.09,.925,'M0 five-position main-qi representation',ha='left',va='top',fontsize=8.2,color='#555555')
ax.set_ylabel('Observed / calendar-null ratio (R)');ax.set_xticks(x);ax.set_xticklabels(labels)
ax.set_ylim(.795,1.205);ax.set_yticks(np.arange(.8,1.201,.05))
ax.text(3,.802,'Replicated feature',ha='center',va='bottom',fontsize=7.3,color=colors[0],fontweight='bold')
ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
# Put the cohort legend in the white band above the plot, entirely outside
# the Hurting Officer highlight and horizontal reference guides.
handles, legend_labels = ax.get_legend_handles_labels()
legend = fig.legend(handles, legend_labels, ncol=3, frameon=False,
                    loc='upper center', bbox_to_anchor=(.5375,.875),
                    borderaxespad=0)
fig.canvas.draw()
renderer = fig.canvas.get_renderer()
legend_box = legend.get_window_extent(renderer)
axes_box = ax.get_window_extent(renderer)
assert legend_box.y0 > axes_box.y1, 'Legend must be fully above plotting area'
# Preserve every plotted ratio and reference guide. No statistical recomputation.
plotted_ratios = np.array([[patch.get_y()+patch.get_height() for patch in group]
                          for group in ax.containers])
expected_ratios = np.array([plot[k+'_ratio'].to_numpy() for k in KEYS])
np.testing.assert_array_equal(plotted_ratios, expected_ratios)
verification = {
    'status': 'PASS',
    'change': 'Move cohort legend into the white band above the axes; no data change',
    'source_sha256': hashlib.sha256((HERE/'figure2_n501_source.csv').read_bytes()).hexdigest(),
    'numeric_source_cells': int(plot.select_dtypes(include='number').size),
    'plotted_ratio_cells_unchanged': int(plotted_ratios.size),
    'legend_clearance_above_axes_points': float((legend_box.y0-axes_box.y1)*72/fig.dpi),
    'mean_sigma_R_unchanged': sigma,
    'legend_outside_highlight': True,
}
(HERE/'verification.json').write_text(json.dumps(verification, indent=2))
for ext in ['png','pdf','svg']:fig.savefig(HERE/f'figure2_chess_tengods_n501.{ext}',dpi=300,bbox_inches='tight',pad_inches=.08)
plt.close(fig)
