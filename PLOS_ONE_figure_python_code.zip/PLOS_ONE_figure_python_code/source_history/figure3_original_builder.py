"""Reproduce Figure 3 from identified frozen result files; no new analysis.

Run from any directory: python build_figure3.py
Dependencies: numpy, pandas, matplotlib.
"""
from pathlib import Path
import json
import hashlib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parent
primary = pd.read_csv(ROOT / "chess_ho_conditional_results_long.csv")
archived = pd.read_csv(ROOT / "archived_figure3_source.csv")
features = ["Direct Resource", "Indirect Resource", "Any Resource", "Seven Killings", "Any Wealth", "Direct Officer"]
cohorts = ["2013_M_DISCOVERY", "2023_M_FULL", "2023_M_NEW_TARGET"]
old_cohorts = ["2013 discovery", "2023 full", "2023 new target"]
rows = []
for cohort, old_cohort in zip(cohorts, old_cohorts):
    for feature in features:
        old = archived.loc[archived["cohort"].eq(old_cohort) & archived["feature"].str.startswith(feature + "\n")].iloc[0]
        if feature == "Any Wealth":
            z, ratio = float(old.z), float(old.ratio)
            source = "archived_figure3_source.csv (later frozen Wealth extension)"
            n = int(primary.loc[primary.cohort.eq(cohort) & primary.model.eq("M0") & primary.target_id.eq("T1"), "n_players_with_H_nonzero"].iloc[0])
            p = np.nan
        else:
            r = primary.loc[primary.cohort.eq(cohort) & primary.model.eq("M0") & primary.target_label.eq(feature)].iloc[0]
            z, ratio = float(r.conditional_z), float(r.conditional_enrichment_ratio)
            n = int(r.n_players_with_H_nonzero)
            p = float(r.conditional_p_enrich)
            source = "chess_ho_conditional_results_long.csv (frozen primary M0)"
        rows.append(dict(cohort=cohort, feature=feature, z=z, ratio=ratio, n_HO_positive=n, p_enrichment=p, source=source,
                         previous_plot_z=float(old.z), previous_plot_ratio=float(old.ratio), delta_z=z-float(old.z)))
data = pd.DataFrame(rows)
data.to_csv(ROOT / "figure3_verified_source.csv", index=False)

plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":9.2, "axes.titlesize":12, "axes.labelsize":10,
    "axes.edgecolor":"#444444", "axes.linewidth":.8, "xtick.labelsize":8.2, "ytick.labelsize":8.5,
    "legend.fontsize":8.3, "figure.facecolor":"white", "axes.facecolor":"white", "savefig.facecolor":"white"})
fig, ax = plt.subplots(figsize=(7.35,4.35))
fig.subplots_adjust(top=.79,bottom=.22,left=.10,right=.985)
colors=["#3B6FB6","#E07A28","#4B9A67"]
labels=["2013 consistency", "2023 full", "2023 new target"]
x=np.arange(len(features)); w=.245
for i, cohort in enumerate(cohorts):
    z=data.loc[data.cohort.eq(cohort),"z"].to_numpy()
    ax.bar(x+(i-1)*w,z,width=w,color=colors[i],edgecolor="white",linewidth=.5,label=labels[i],zorder=3)
ax.axhline(0,color="#222222",lw=1.15,zorder=4)
for val in (-2,-1,1,2):
    ax.axhline(val,color="#A8ADB4",lw=.65,ls=(0,(3,3)),alpha=.75,zorder=1)
fig.suptitle("Hurting-Officer-conditioned companion structures",x=.10,y=.975,ha="left",fontweight="bold",fontsize=12)
fig.text(.10,.922,"Necessary-component tests under the exact-year conditional null",ha="left",va="top",fontsize=8.2,color="#555555")
ax.set_ylabel("Conditional-null deviation (Z)")
ax.set_xticks(x); ax.set_xticklabels([f.replace(" ","\n",1) for f in features])
ax.set_ylim(-2.55,2.75); ax.set_yticks(np.arange(-2,3,1))
ax.legend(ncol=3,frameon=False,loc="upper center",bbox_to_anchor=(.56,1.01))
ax.spines["top"].set_visible(False); ax.spines["right"].set_visible(False)
for ext in ("png","svg","pdf"):
    fig.savefig(ROOT / ("figure3_ho_conditional_verified."+ext),dpi=300,bbox_inches="tight",pad_inches=.12)
plt.close(fig)
manifest={"purpose":"Figure 3 source alignment; no new hypothesis or simulation", "frozen_ref":"manuscript-figures-v1",
          "primary_source_url":"https://github.com/agenhcx/bazi-public-figure-study/blob/manuscript-figures-v1/chess_ho_conditional_structure_v1/chess_ho_conditional_results_long.csv",
          "original_figure_source_url":"https://github.com/agenhcx/bazi-public-figure-study/blob/manuscript-figures-v1/figure_repro_v1/data/figure3_ho_conditional_zscore_sigma_source.csv",
          "max_abs_z_correction":float(data.delta_z.abs().max()),
          "explanation":"The archived plotting data and primary frozen output contain slightly different Monte Carlo Z summaries. An upstream derivation for the plot-only variant is not recorded in the manifest. The five primary companion features now read directly from the primary frozen result; Any Wealth retains its later-extension archived plot values. All signs and qualitative conclusions are unchanged.",
          "files":{p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in ROOT.iterdir() if p.is_file() and p.name!="source_manifest.json"}}
(ROOT/"source_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
print(json.dumps({"max_abs_z_correction":manifest["max_abs_z_correction"],"outputs":"figure3_ho_conditional_verified.{png,svg,pdf}"}))
