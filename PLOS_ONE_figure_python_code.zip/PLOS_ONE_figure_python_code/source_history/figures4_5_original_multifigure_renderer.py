from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import FancyBboxPatch
from matplotlib.lines import Line2D


OUT = Path("/workspace/scratch/fd92b079dc91/tmp/review_oct12/corrected_figures")
OUT.mkdir(parents=True, exist_ok=True)

plt.rcParams.update(
    {
        "font.family": "DejaVu Sans",
        "font.size": 9.2,
        "axes.titlesize": 12,
        "axes.labelsize": 10,
        "axes.edgecolor": "#444444",
        "axes.linewidth": 0.8,
        "xtick.labelsize": 8.2,
        "ytick.labelsize": 8.5,
        "legend.fontsize": 8.3,
        "figure.facecolor": "white",
        "axes.facecolor": "white",
        "savefig.facecolor": "white",
    }
)

BLUE = "#3B6FB6"
ORANGE = "#E07A28"
GREEN = "#4B9A67"
RED = "#C75252"
GRAY = "#7A7F87"
LIGHT_GRID = "#D9DDE3"


def finish(fig, name):
    fig.savefig(OUT / name, dpi=300, bbox_inches="tight", pad_inches=0.08)
    plt.close(fig)


def clean_axes(ax, ygrid=True):
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    if ygrid:
        ax.grid(axis="y", color=LIGHT_GRID, linewidth=0.65, alpha=0.8)
        ax.set_axisbelow(True)


# Figure 1: workflow
fig, ax = plt.subplots(figsize=(7.3, 3.45))
ax.set_xlim(0, 1)
ax.set_ylim(0, 1)
ax.axis("off")
ax.set_title("From traditional propositions to reproducible population tests", loc="left", pad=10, fontweight="bold")

steps = [
    ("Theory or\nexploratory\nfinding", "Interpretive source"),
    ("Fixed\noperational\ndefinition", "Feature and direction"),
    ("Calendar-\nconditioned\nnull model", "Same Gregorian year"),
    ("Freeze or\npreregister", "Cohort and analysis"),
    ("Independent\nreplication\nor transfer", "New people or domain"),
]
xs = np.linspace(0.105, 0.895, len(steps))
box_w, box_h, y = 0.16, 0.28, 0.57
for i, ((main, sub), x) in enumerate(zip(steps, xs)):
    fc = "#EEF3FA" if i in (1, 2, 3) else "#F4F5F6"
    ec = BLUE if i in (1, 2, 3) else GRAY
    patch = FancyBboxPatch(
        (x - box_w / 2, y - box_h / 2),
        box_w,
        box_h,
        boxstyle="round,pad=0.012,rounding_size=0.018",
        linewidth=1.1,
        edgecolor=ec,
        facecolor=fc,
    )
    ax.add_patch(patch)
    ax.text(x, y + 0.035, main, ha="center", va="center", fontsize=7.2, fontweight="bold", linespacing=1.05)
    ax.text(x, y - 0.102, sub, ha="center", va="center", fontsize=6.3, color="#555555")
    if i < len(steps) - 1:
        ax.annotate(
            "",
            xy=(xs[i + 1] - box_w / 2 - 0.008, y),
            xytext=(x + box_w / 2 + 0.008, y),
            arrowprops=dict(arrowstyle="-|>", color="#666666", lw=1.0),
        )

outcomes_y = 0.16
ax.text(0.105, outcomes_y, "Compound\nclaims", ha="center", va="center", color="#444444", fontweight="bold", fontsize=8.0)
bottom_specs = [
    (0.42, 0.34, "Frozen component tests", "#F7F7F7", "#A5A8AC"),
    (0.81, 0.31, "Retain enrichment, null, or reversal", "#EEF3FA", BLUE),
]
for bx, bw, txt, fc, ec in bottom_specs:
    patch = FancyBboxPatch((bx - bw / 2, outcomes_y - 0.045), bw, 0.09,
                           boxstyle="round,pad=0.004,rounding_size=0.01",
                           linewidth=0.8, edgecolor=ec, facecolor=fc, zorder=2)
    ax.add_patch(patch)
    ax.text(bx, outcomes_y, txt, ha="center", va="center", fontsize=7.2, zorder=3)
ax.annotate("", xy=(0.245, outcomes_y), xytext=(0.19, outcomes_y), arrowprops=dict(arrowstyle="-|>", color="#777777", lw=0.9))
ax.annotate("", xy=(0.65, outcomes_y), xytext=(0.595, outcomes_y), arrowprops=dict(arrowstyle="-|>", color="#777777", lw=0.9))
finish(fig, "figure1_workflow.png")


# Shared labels and cohort colors
labels = [
    "Friend",
    "Rob\nWealth",
    "Eating\nGod",
    "Hurting\nOfficer",
    "Indirect\nWealth",
    "Direct\nWealth",
    "Seven\nKillings",
    "Direct\nOfficer",
    "Indirect\nResource",
    "Direct\nResource",
]


# Figure 2: chess profiles
import pandas as pd
profile = pd.read_csv('/workspace/scratch/fd92b079dc91/tmp/review_oct12/figure_repro_v1/data/figure2_deviation_bar_source.csv')
keys = ['2013_M_DISCOVERY', '2023_M_FULL', '2023_M_NEW_TARGET']
chess = np.array([profile[k + '_ratio'].to_numpy() for k in keys])
cohorts = ['2013 descriptive (492)', '2023 full (501)', '2023 new (501)']
colors = [BLUE, ORANGE, GREEN]
x = np.arange(len(labels))
w = 0.245
fig, ax = plt.subplots(figsize=(7.5, 4.65))
fig.subplots_adjust(top=0.80, bottom=0.23, left=0.09, right=0.985)
ax.axvspan(2.5, 3.5, color="#EDF3FA", zorder=0)
for i in range(3):
    ax.bar(x + (i - 1) * w, chess[i] - 1, bottom=1, width=w, color=colors[i], edgecolor="white", linewidth=0.5,
           label=cohorts[i], zorder=3)
ax.axhline(1, color="#222222", lw=1.15, zorder=4)
sigma = float(profile[[k + "_sigma_r" for k in keys]].to_numpy().mean())
for n in (1, 2, 3):
    for sign in (-1, 1):
        val = 1 + sign * n * sigma
        ax.axhline(val, color="#777777", lw=0.65 if n < 3 else 0.8, ls=(0, (2, 2)) if n < 3 else (0, (5, 3)), alpha=0.55, zorder=1)
    ax.text(len(labels) - 0.42, 1 + n * sigma + 0.004, f"+{n}σ", ha="right", va="bottom", fontsize=7.2, color="#666666")
    ax.text(len(labels) - 0.42, 1 - n * sigma - 0.004, f"−{n}σ", ha="right", va="top", fontsize=7.2, color="#666666")
fig.suptitle("Ten-God profiles across male elite-chess cohorts", x=0.09, y=0.975, ha="left", fontweight="bold", fontsize=12)
fig.text(0.09, 0.925, "M0 five-position main-qi representation", ha="left", va="top", fontsize=8.2, color="#555555")
ax.set_ylabel("Observed / calendar-null ratio (R)")
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_ylim(0.795, 1.205)
ax.set_yticks(np.arange(0.80, 1.201, 0.05))
ax.legend(ncol=3, frameon=False, loc="upper center", bbox_to_anchor=(0.55, 1.015))
ax.text(3, 0.802, "Replicated feature", ha="center", va="bottom", fontsize=7.3, color=BLUE, fontweight="bold")
clean_axes(ax, ygrid=False)
finish(fig, "figure2_chess_tengods.png")


# Figure 3: conditional components as Z scores
cohorts = ["2013 consistency", "2023 full", "2023 new target"]
features = ["Direct\nResource", "Indirect\nResource", "Any\nResource", "Seven\nKillings", "Any\nWealth", "Direct\nOfficer"]
z = np.array(
    [
        [-1.2995416291, 1.3770954806, -1.1090832502, -0.3280700397, -1.9369108818, 2.3190130385],
        [-0.7008519559, 0.6335155502, -0.4074537752, -0.50578806698, -0.6934027008, 1.4078806619],
        [-0.6090675770, 0.0067894494, -0.5386128141, -1.3750700767, 1.1870185065, -1.3580036829],
    ]
)
x = np.arange(len(features))
fig, ax = plt.subplots(figsize=(7.35, 4.35))
fig.subplots_adjust(top=0.79, bottom=0.22, left=0.10, right=0.985)
for i in range(3):
    ax.bar(x + (i - 1) * w, z[i], width=w, color=colors[i], edgecolor="white", linewidth=0.5, label=cohorts[i], zorder=3)
ax.axhline(0, color="#222222", lw=1.15, zorder=4)
for val in (-2, -1, 1, 2):
    ax.axhline(val, color="#A8ADB4", lw=0.65, ls=(0, (3, 3)), alpha=0.75, zorder=1)
fig.suptitle("Hurting-Officer-conditioned companion structures", x=0.10, y=0.975, ha="left", fontweight="bold", fontsize=12)
fig.text(0.10, 0.922, "Necessary-component tests under the exact-year conditional null", ha="left", va="top", fontsize=8.2, color="#555555")
ax.set_ylabel("Standardized deviation from conditional null (Z)")
ax.set_xticks(x)
ax.set_xticklabels(features)
ax.set_ylim(-2.55, 2.75)
ax.set_yticks(np.arange(-2, 3, 1))
ax.legend(ncol=3, frameon=False, loc="upper center", bbox_to_anchor=(0.56, 1.01))
clean_axes(ax, ygrid=False)
finish(fig, "figure3_ho_conditional.png")


# Figure 4: historical versus modern table tennis
hist = np.array([0.9247539469, 0.8310784193, 0.9482906170, 1.0609624471, 1.0809316829, 1.0934944664, 0.9877358933, 1.0235664902, 0.9889858798, 1.0703926841])
modern = np.array([0.9457080319, 1.1238811139, 1.0058073186, 0.9973640514, 0.9221895628, 0.9708227272, 0.9943528930, 1.0616315643, 0.9909484432, 1.0078818042])
x = np.arange(len(labels))
w4 = 0.36
fig, ax = plt.subplots(figsize=(7.5, 4.65))
fig.subplots_adjust(top=0.78, bottom=0.22, left=0.09, right=0.985)
ax.axvspan(0.5, 1.5, color="#F5F1E9", zorder=0)
ax.bar(x - w4 / 2, hist - 1, bottom=1, width=w4, color=GRAY, edgecolor="white", linewidth=0.5,
       label="Historical 1950–1984 (N=335)", zorder=3)
ax.bar(x + w4 / 2, modern - 1, bottom=1, width=w4, color=BLUE, edgecolor="white", linewidth=0.5,
       label="Modern 1985–2008 (N=384)", zorder=3)
ax.axhline(1, color="#222222", lw=1.15, zorder=4)
sig_hist, sig_mod = 0.0775, 0.0689
for n in (1, 2, 3):
    for sign in (-1, 1):
        ax.axhline(1 + sign * n * sig_hist, color=GRAY, lw=0.6, ls=(0, (5, 3)), alpha=0.30, zorder=1)
        ax.axhline(1 + sign * n * sig_mod, color=BLUE, lw=0.6, ls=(0, (1.5, 2.2)), alpha=0.28, zorder=1)
guide_handles = [
    Line2D([0], [0], color=GRAY, lw=1.0, ls=(0, (5, 3)), label="Historical σR≈0.0775"),
    Line2D([0], [0], color=BLUE, lw=1.0, ls=(0, (1.5, 2.2)), label="Modern σR≈0.0689"),
]
fig.suptitle("Historical and modern Ten-God profiles in elite table tennis", x=0.09, y=0.975, ha="left", fontweight="bold", fontsize=12)
fig.text(0.09, 0.922, "M0 five-position main-qi representation", ha="left", va="top", fontsize=8.2, color="#555555")
ax.set_ylabel("Observed / calendar-null ratio (R)")
ax.set_xticks(x)
ax.set_xticklabels(labels)
ax.set_ylim(0.75, 1.25)
ax.set_yticks(np.arange(0.75, 1.251, 0.05))
leg1 = ax.legend(ncol=2, frameon=False, loc="upper center", bbox_to_anchor=(0.53, 1.012))
ax.add_artist(leg1)
ax.legend(handles=guide_handles, ncol=1, frameon=False, loc="lower right", bbox_to_anchor=(0.998, 0.012), fontsize=7.0,
          handlelength=2.3, borderaxespad=0.2)
ax.text(1, 0.755, "Largest cohort contrast", ha="center", va="bottom", fontsize=7.3, color="#8A5E24", fontweight="bold")
clean_axes(ax, ygrid=False)
finish(fig, "figure4_tt_profiles.png")


# Figure 5: fixed-window temporal comparison
windows = ["1955–1964", "1965–1974", "1975–1984", "1985–1994", "1995–2004"]
tt = np.array([0.679365, 0.763996, 0.915447, 1.209910, 1.083177])
ch = np.array([0.972320, 1.061687, 0.911052, 1.060155, 1.030556])
x = np.arange(len(windows))
fig, ax = plt.subplots(figsize=(7.35, 4.25))
fig.subplots_adjust(top=0.79, bottom=0.20, left=0.10, right=0.985)
ax.axhline(1, color="#222222", lw=1.15, zorder=1)
ax.plot(x, tt, color=BLUE, marker="o", ms=6.2, lw=1.9, label="Table tennis", zorder=3)
ax.plot(x, ch, color=RED, marker="s", ms=5.7, lw=1.9, label="Chess", zorder=3)
ax.axvline(2.5, color="#888888", lw=0.8, ls=(0, (4, 3)), zorder=1)
ax.text(2.53, 0.77, "1985 cohort boundary", rotation=90, va="bottom", ha="left", fontsize=7.5, color="#666666")
fig.suptitle("Rob Wealth across the same five complete birth-year windows", x=0.10, y=0.975, ha="left", fontweight="bold", fontsize=12)
fig.text(0.10, 0.922, "Connected points show ordered windows; partial edge windows are excluded", ha="left", va="top", fontsize=8.2, color="#555555")
ax.set_ylabel("Observed / calendar-null ratio (R)")
ax.set_xticks(x)
ax.set_xticklabels(windows)
ax.set_ylim(0.64, 1.27)
ax.set_yticks(np.arange(0.7, 1.251, 0.1))
ax.legend(frameon=False, loc="upper left")
ax.text(0.985, 0.06, "Table tennis: ρ=0.11368, directional p=.011\nChess: ρ=0.02198, directional p=.428",
        transform=ax.transAxes, ha="right", va="bottom", fontsize=8.1,
        bbox=dict(boxstyle="round,pad=0.28", facecolor="white", edgecolor="#C9CDD2", linewidth=0.7, alpha=0.92))
clean_axes(ax, ygrid=True)
finish(fig, "figure5_temporal_transfer.png")

print("\n".join(str(p) for p in sorted(OUT.glob("*.png"))))
