from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Polygon, FancyArrowPatch
from matplotlib.path import Path as MplPath


OUT = Path(__file__).resolve().parent
plt.rcParams.update({
    'font.family': 'DejaVu Sans',
    'font.size': 9.5,
    'svg.fonttype': 'none',
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
})

fig = plt.figure(figsize=(6.5, 6.8), facecolor='white')
ax = fig.add_axes([0.01, 0.015, 0.98, 0.97])
ax.set(xlim=(0, 10), ylim=(0, 10))
ax.axis('off')

ink = '#20364B'
line = '#4C5967'
blue = '#416B91'
green = '#287C68'
orange = '#A85D3E'
gray = '#637184'


def box(x, y, w, h, title, sub=None, edge=blue, fill='#EDF3F8', fs=9.5):
    ax.add_patch(FancyBboxPatch(
        (x-w/2, y-h/2), w, h,
        boxstyle=f'round,pad=0,rounding_size={min(0.32, h*0.40)}',
        lw=1.2, edgecolor=edge, facecolor=fill, zorder=3,
    ))
    if sub:
        ax.text(x, y+0.13, title, ha='center', va='center',
                fontsize=fs, weight='bold', color=ink, zorder=4)
        ax.text(x, y-0.20, sub, ha='center', va='center',
                fontsize=9.5, color=ink, linespacing=1.2, zorder=4)
    else:
        ax.text(x, y, title, ha='center', va='center',
                fontsize=fs, weight='medium', color=ink,
                linespacing=1.25, zorder=4)


def arrow(points, color=line, lw=1.15, head=True):
    path = MplPath(points, [MplPath.MOVETO] + [MplPath.LINETO]*(len(points)-1))
    ax.add_patch(FancyArrowPatch(
        path=path, arrowstyle='-|>' if head else '-',
        mutation_scale=10.5, linewidth=lw,
        color=color, capstyle='round', joinstyle='round', zorder=2,
    ))


# Initial inference-to-test sequence.
box(5.0, 9.25, 5.2, 0.95,
    'Traditional proposition', 'or exploratory finding')
box(5.0, 7.85, 5.2, 1.02,
    'Specify and freeze the test',
    'Feature · direction · cohort · calendar null')
box(5.0, 6.50, 5.2, 0.88,
    'Test the independent cohort', 'Apply the frozen analysis')
arrow([(5, 8.775), (5, 8.36)])
arrow([(5, 7.34), (5, 6.94)])

# A conventional three-way decision diamond.
dy = 5.23
dw = 1.50
dh = 0.72
ax.add_patch(Polygon([(5, dy+dh), (5+dw, dy), (5, dy-dh), (5-dw, dy)],
                     closed=True, edgecolor=blue, facecolor='#EDF3F8',
                     linewidth=1.2, zorder=3))
ax.text(5, dy+0.09, 'Reveal results', ha='center', va='center',
        fontsize=9.5, weight='bold', color=ink, zorder=4)
ax.text(5, dy-0.21, 'Classify outcome', ha='center', va='center',
        fontsize=9.5, color=ink, zorder=4)
arrow([(5, 6.06), (5, dy+dh)])

# Outcome nodes are explicit and accessible independently of color.
box(1.85, 3.89, 2.60, 0.72, 'Enrichment',
    edge=green, fill='#EAF5EF', fs=10)
box(5.00, 3.80, 2.60, 0.90, 'Null', 'Estimate + uncertainty',
    edge=gray, fill='#F0F2F5', fs=10)
box(8.15, 3.89, 2.60, 0.72, 'Depletion',
    edge=orange, fill='#FBF0E9', fs=10)
arrow([(3.50, dy), (1.85, dy), (1.85, 4.25)], color=green)
arrow([(5, dy-dh), (5, 4.25)], color=gray)
arrow([(6.50, dy), (8.15, dy), (8.15, 4.25)], color=orange)

# Enrichment offers parallel choices, not a required sequence.
box(2.10, 2.72, 3.00, 0.74, 'Further replication\ntest',
    edge=green, fill='#F4F9F6')
box(2.10, 1.72, 3.00, 0.74, 'Compound / conditional\ntest',
    edge=green, fill='#F4F9F6')
box(2.10, 0.72, 3.00, 0.74, 'Cross-domain\ntest',
    edge=green, fill='#F4F9F6')

# Left fan-out and right merge make the alternatives visually parallel.
arrow([(1.85, 3.53), (1.85, 3.27), (0.39, 3.27), (0.39, 0.72)],
      color=green, head=False)
for y in (2.72, 1.72, 0.72):
    arrow([(0.39, y), (0.60, y)], color=green)
    arrow([(3.60, y), (3.94, y)], color=green, head=False)
arrow([(3.94, 2.72), (3.94, 0.13), (0.12, 0.13), (0.12, 7.85), (2.40, 7.85)],
      color=green)

# Opposite-direction results can motivate a newly specified hypothesis.
box(8.15, 2.60, 2.60, 0.90, 'Form a new\nproposition',
    edge=orange, fill='#FBF0E9', fs=9.5)
arrow([(8.15, 3.53), (8.15, 3.05)], color=orange)
arrow([(9.45, 2.60), (9.82, 2.60), (9.82, 9.25), (7.60, 9.25)],
      color=orange)

for ext in ('svg', 'pdf', 'png'):
    fig.savefig(OUT / f'figure1_workflow.{ext}', dpi=300, facecolor='white')
plt.close(fig)

caption = (
    'Fig 1. A reproducible workflow for population tests of BaZi propositions. '
    'A traditional proposition or exploratory finding is translated into a frozen '
    'feature definition, test direction, eligible cohort, and calendar reference model '
    'before evaluation in independent data. Revealed results are classified as enrichment, '
    'null, or depletion using the prespecified decision rule, with effect estimates and '
    'uncertainty reported for every outcome. Enrichment can motivate further replication, '
    'a compound or conditional test, or a cross-domain test; each follow-up returns to '
    'protocol specification and freezing before a fresh independent evaluation. Depletion '
    'can motivate a new proposition that enters the same prospective workflow. A null '
    'result denotes insufficient directional evidence under the specified test, rather '
    'than evidence of exact equality.'
)
(OUT / 'caption.txt').write_text(caption + '\n', encoding='utf-8')
