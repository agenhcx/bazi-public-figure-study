# BaZi manuscript figure Python archive

This archive reproduces main Figures 1–5 and supplementary Figure S1 from their frozen plotting inputs. It is intended for the author's local preservation. No network access, private credentials, original workspace, or calendar library is needed to render the figures once dependencies and the publication font are installed. Arial is required (normally available on Windows); install a licensed Arial font before running on other systems. Font files are not distributed in this archive. The renderer stops rather than silently substituting a different font.

## Run

Use Python 3.10 or newer (verified with Python 3.12.14). In a terminal inside this directory:

```bash
python -m venv .venv
# macOS / Linux
source .venv/bin/activate
# Windows PowerShell instead: .venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
python render_all.py
```

The `figures/` directory receives six figures in PNG, PDF and SVG formats. `verification/render_all.json` records the input hashes and numerical plotting checks. Each renderer can also be run separately, for example `python scripts/render_figureS1.py`.

## Files

- `render_all.py`: one entry point for all six figures.
- `scripts/`: portable renderers and shared plotting helpers.
- `inputs/`: frozen plot data; these are the inputs needed for this rendering workflow.
- `figures/`: verified outputs included for immediate reference.
- `verification/`: automated endpoint, baseline and series-order checks.
- `source_history/`: historical source scripts retained as provenance; run the portable scripts above rather than these historical scripts.
- `provenance.json`: origin and numerical precision of each figure.

## What is reproduced

Figure 1 retains the rounded workflow, three reveal outcomes and follow-up loops. Figure 2 uses the verified n=501 male cohorts and the later legend layout. Figure 3 reads its verified conditional source, including the separately archived Any Wealth extension. Figures 4 and 5 retain the precise decimal values actually used in the current manuscript plots; their original full-precision source CSVs are also provided. Existing temporal rho and p annotations are preserved as published plotting annotations.

Supplementary Figure S1 keeps all 30 female-cohort ratios and their ordering, colours, cohort sizes and post-reveal descriptive labels. Its bars now start at R=1 (height R-1, bottom 1), matching the interpretation of main Figures 2 and 4; the y-axis displays 0.65–1.35. Dashed horizontal guides now match Fig2: +/-1, +/-2 and +/-3 times the mean of the 30 exact cell-specific sigma_R values (null SD / expected count), around R=1. The mean is 0.09700548728425677. These are approximate visual guides rather than common exact significance thresholds; each cell retains its own SD and expectation in the input CSV. There are no new tests or changed effect estimates.

This is a complete archive for rendering these six figures. It does not rerun the underlying cohort collection, BaZi encoding, Monte Carlo tests or exact-convolution analyses. Those statistical workflows and original data provenance remain in the study repository and audit archives. Matplotlib/Python/platform differences may slightly affect fonts or PDF metadata without changing plotted values.

## Publication formatting update

Main figure text uses Arial at 8-12 pt at the native 300-dpi export size. Overall main-figure titles/subtitles reside in the manuscript captions. All frozen input bytes, 98 bar endpoints, 10 line points, bar origins and sigma guides remain unchanged. The code produces PNG, PDF and SVG; submission TIFFs are lossless RGB/LZW conversions of the PNGs, with no resampling. See verification/publication_compliance.json.
